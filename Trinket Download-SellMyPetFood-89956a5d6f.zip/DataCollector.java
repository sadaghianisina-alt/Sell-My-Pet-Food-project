/*
 * Problem 2.3.1 Sell My Pet Food
 * 
 * V1.0
 * 6/1/2019
 * Copyright(c) 2019 PLTW to present. All rights reserved
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;

/**
 * A DataCollector class to manage social media posts
 */
 
public class DataCollector {

    static class Post {
        String user;
        String text;
        Post(String u, String t) { user = u; text = t; }
    }

    private ArrayList<Post> posts = new ArrayList<>(); 
    public void loadAllPosts(String smallFile, String bigFile) {
        loadPostsFromFile(smallFile);
        loadPostsFromFile(bigFile);
    }
/**
   * Gather the data contained in the files socialMediaPostsFilename and
   * targetWordsFilename (including punctuation), with words separated by a single
   * space
   * 
   * @param socialMediaPostsFilename the name of the file containing social media posts
   * @param targetWordsFilename the name of the file containing the target words
   */ 
   
    private void loadPostsFromFile(String filename) {
       // read in the social media posts found in socialMediaPosts
    // a try is like an if statement, "throwing" an error if the body of the try fails
    
        try {
            Scanner sc = new Scanner(new File(filename));
            while (sc.hasNextLine()) {
        String line = sc.nextLine().trim();
      int firstSpace = line.indexOf(" ");
      int firstQuote = line.indexOf("\"");
      int lastQuote = line.lastIndexOf("\"wqs");
      if (firstSpace > 0 && firstQuote >= 0 && lastQuote > firstQuote) {
      String user = line.substring(0, firstSpace).trim();
      String msg  = line.substring(firstQuote + 1, lastQuote).trim();
                    posts.add(new Post(user, msg));}
   }
            sc.close();
  } catch (Exception e) { // if not found than it skips it
     // read in the target words in targetWords

        }
    }

   
    public String findFirstCommentForKeyword(String keyword) {
        if (keyword == null) return null;
        String k = keyword.toLowerCase();
        for (Post p : posts) {
            if (p.text != null && p.text.toLowerCase().contains(k)) {
                return p.text; 
            }
        }
        return null; // if none found
    }
 /**
   * Get the next post in socialMediaPosts with words separated by a single space, 
   * or "NONE" if there is no more data.
   * 
   * @return a string containing one of the lines in socialMediaPosts
   */
   //I did ths part in TargetAD
     // read in the target words in targetWords
    public String pickAdMessageForKeyword(String keyword) {
        if (keyword == null) return "Pet food sale!";
        String k = keyword.toLowerCase(); // ad message based on what the keyword os

//
  if (k.contains("dog") || k.contains("puppy"))  return "Buy dog food and save!";
  if (k.contains("cat") || k.contains("kitty") || k.contains("kitten")) return "Cat food deal today!";
  if (k.contains("bird"))        return "Bird food bundle!";
  if (k.contains("fish"))        return "Aquarium & fish flakes sale!";
  if (k.contains("hamster"))     return "Hamster cages and bedding discount!";
  if (k.contains("rabbit"))      return "Rabbit hay and treats special!";
  if (k.contains("turtle"))      return "Turtle tanks and lamps offer!";
  if (k.contains("lion") || k.contains("wolf")) return "Wild-themed apparel on sale!";
  if (k.contains("leash") || k.contains("collar")) return "Leashes & collars 20% off!";
  if (k.contains("treat"))       return "Pet treats buy 2 get 1 free!";
  if (k.contains("chew"))        return "Tough chew toys markdowns!";
  if (k.contains("raincoat"))    return "Pet raincoats 15% off!";
  if (k.contains("kennel") || k.contains("crate") || k.contains("hotel")) return "Boarding & crates promo!";
  if (k.contains("hotdog"))      return "Game day hotdog bundle!";
  if (k.contains("purr") || k.contains("meow")) return "Catnip toys special!";
  if (k.contains("bark"))        return "Dog training treats deal!";

        return "Pet food sale!";
    }
    
      /**
   * Create a File named filename and stores all the usernames to target
   * 
   * @param filename The name to save the file, must include .txt
   * @param usernames A string containing the usernames of people to target,
   * usernames are separated by a space.
   */

 /**
   * Print the array of posts
   */
    public void prepareAdvertisement(String matchedComment, String adMessage) {
       /**
   * Print the array of target words
   */
        try {
            PrintWriter out = new PrintWriter("advertisement.txt");
            out.println("Ad Message: " + adMessage);
            out.println("Matched comment: " + matchedComment);
            out.close();
        } catch (Exception e) {
            System.out.println("Could not write advertisement.txt");
        }
    }
}